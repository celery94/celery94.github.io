import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.error
import urllib.request

PG = Path(os.environ.get("SERIES_PG_BIN", "C:/Program Files/PostgreSQL/18/bin"))
variants = (("net10-baseline", "net10-baseline", "net10.0", "net10_baseline", 5110, "false"),
            ("net11-upgrade", "net11-upgrade", "net11.0", "net11_upgrade", 5111, "false"),
            ("net11-compat", "net11-upgrade", "net11.0", "net11_upgrade", 5111, "true"))
Path("snapshots").mkdir(exist_ok=True)

def get(url, body=None, headers=None):
    if body is None:
        req = urllib.request.Request(url, headers=headers or {})
    else:
        req = urllib.request.Request(url, json.dumps(body).encode(),
                                     {"Content-Type": "application/json"})
    try:
        response = urllib.request.urlopen(req, timeout=10)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        return response.status, response.headers.get("Content-Type", ""), response.read().decode()

for label, folder, tfm, db, port, compat in variants:
    conn = os.environ.get(
        "SERIES_PG_TEMPLATE", "Host=127.0.0.1;Port=55431;Database={db};Username=series")
    subprocess.run([str(PG / "psql.exe"), "-h", "127.0.0.1", "-p", "55431", "-U", "series",
                   "-d", db, "-v", "ON_ERROR_STOP=1", "-c", """
        TRUNCATE enrollments;
        CREATE OR REPLACE FUNCTION pause_race() RETURNS trigger LANGUAGE plpgsql AS
        $$ BEGIN IF NEW.student = 'RACE' THEN PERFORM pg_sleep(1); END IF; RETURN NEW; END $$;
        CREATE OR REPLACE TRIGGER pause_race BEFORE INSERT ON enrollments
        FOR EACH ROW EXECUTE FUNCTION pause_race();
    """], check=True, stdout=subprocess.DEVNULL)
    url = f"http://127.0.0.1:{port}"
    env = dict(os.environ, ConnectionStrings__Enrollment=conn.format(db=db),
               ASPNETCORE_URLS=url, OpenApi__Compatibility=compat)
    with Path("snapshots", label + "-server.log").open("w") as log:
        server = subprocess.Popen(["dotnet", f"{folder}/bin/Debug/{tfm}/Web.dll"],
                                  stdout=log, stderr=subprocess.STDOUT, env=env)
        try:
            for retry in range(80):
                try:
                    status, _, raw = get(url + "/openapi/v1.json")
                    if status == 200:
                        break
                except urllib.error.URLError:
                    time.sleep(.25)
            else:
                raise RuntimeError("OpenAPI endpoint did not start")
            Path("snapshots", label + ".json").write_text(raw, encoding="utf-8")
            document = json.loads(raw)
            versions = document["openapi"]
            stream = document["paths"]["/progress"]["get"]["responses"]["200"]["content"]["text/event-stream"]
            checks = {}
            enroll = url + "/enrollments"
            for name, value, expected in [
                ("success", {"student": "S01", "course": "C101"}, 200),
                ("missing", {"student": "S01", "course": "C999"}, 404),
                ("duplicate", {"student": "S01", "course": "C101"}, 400),
                ("empty", {"student": "", "course": "C101"}, 400),
            ]:
                code, media, result = get(enroll, value)
                assert code == expected, (folder, name, code, result)
                checks[name] = [code, media, json.loads(result)]
            with concurrent.futures.ThreadPoolExecutor(2) as pool:
                results = list(pool.map(lambda _: get(enroll, {"student": "RACE", "course": "C102"}), range(2)))
            codes = sorted(row[0] for row in results)
            assert codes == [200, 409], (folder, codes, results)
            checks["race"] = codes
            status, media, events = get(url + "/progress")
            assert status == 200 and media.startswith("text/event-stream")
            assert 'id: 1' in events and 'id: 2' in events and '"state":"done"' in events, events
            checks["sse"] = events
            code, _, resumed = get(url + "/progress", headers={"Last-Event-ID": "1"})
            assert code == 200 and "id: 1" not in resumed and "id: 2" in resumed, resumed
            checks["sse_resume"] = resumed
            session = url + "/demo-session"
            code, _, _ = get(session, headers={"Authorization": "Bearer series-demo-expired"})
            assert code == 401, code
            code, _, _ = get(session, headers={"Authorization": "Bearer series-demo-valid"})
            assert code == 200, code
            checks["mock_session"] = [401, 200]
            print(label, versions, stream, checks)
            Path("snapshots", label + "-http.json").write_text(
                json.dumps(checks, indent=2) + "\n", encoding="utf-8")
        finally:
            server.terminate()
            server.wait(timeout=10)
