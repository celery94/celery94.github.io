using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using System.Net.ServerSentEvents;
using Microsoft.AspNetCore.Http.HttpResults;
using Npgsql;

var builder = WebApplication.CreateBuilder(args);
#if NET11_0_OR_GREATER
builder.Services.AddOpenApi(options =>
{
    if (builder.Configuration.GetValue<bool>("OpenApi:Compatibility"))
        options.OpenApiVersion = Microsoft.OpenApi.OpenApiSpecVersion.OpenApi3_1;
});
#else
builder.Services.AddOpenApi();
#endif
#if NET11_0_OR_GREATER
builder.Services.AddValidation();
#endif
builder.Services.AddSingleton(_ => NpgsqlDataSource.Create(
    builder.Configuration.GetConnectionString("Enrollment")
    ?? throw new InvalidOperationException("Set ConnectionStrings__Enrollment.")));
var app = builder.Build();
app.MapOpenApi();
app.MapPost("/enrollments", Enroll).WithName("Enroll")
    .ProducesValidationProblem();
app.MapGet("/progress", (HttpContext context, CancellationToken ct) =>
    TypedResults.ServerSentEvents(Progress(context.Request.Headers["Last-Event-ID"], ct)))
    .WithName("WatchProgress");
app.MapGet("/demo-session", (HttpContext context) =>
    context.Request.Headers.Authorization == "Bearer series-demo-valid"
        ? (IResult)TypedResults.Ok(new { name = "student" })
        : TypedResults.Unauthorized()).WithName("DemoSession").Produces(401);
#if NET11_0_OR_GREATER
app.MapGet("/course-state", (bool exists) =>
    exists ? new CourseState(new Available("C101")) :
             new CourseState(new Missing("course_missing"))).WithName("CourseState");
#endif
app.Run();

static async Task<Results<Ok<Receipt>, NotFound<Failure>, Conflict<Failure>, ValidationProblem>>
    Enroll(Enrollment body, NpgsqlDataSource data, CancellationToken ct)
{
#if !NET11_0_OR_GREATER
    if (string.IsNullOrWhiteSpace(body.Student) || string.IsNullOrWhiteSpace(body.Course))
        return TypedResults.ValidationProblem(new Dictionary<string, string[]>
        {
            ["request"] = ["student and course are required"]
        });
    if (await Enrollment.Exists(data, body.Student, body.Course, ct))
        return TypedResults.ValidationProblem(new Dictionary<string, string[]>
        {
            [nameof(Enrollment.Course)] = ["already enrolled"]
        });
#endif
    await using var command = data.CreateCommand("""
        INSERT INTO enrollments(student, course)
        SELECT $1, code FROM courses WHERE code = $2
        ON CONFLICT (student, course) DO NOTHING
        RETURNING course
        """);
    command.Parameters.AddWithValue(body.Student);
    command.Parameters.AddWithValue(body.Course);
    if (await command.ExecuteScalarAsync(ct) is string course)
        return TypedResults.Ok(new Receipt(body.Student, course));
    await using var checkCourse = data.CreateCommand("SELECT 1 FROM courses WHERE code = $1");
    checkCourse.Parameters.AddWithValue(body.Course);
    if (await checkCourse.ExecuteScalarAsync(ct) is null)
        return TypedResults.NotFound(new Failure("course_missing"));
    return TypedResults.Conflict(new Failure("enrollment_conflict"));
}

static async IAsyncEnumerable<SseItem<ProgressUpdate>> Progress(
    string? lastEvent,
    [EnumeratorCancellation] CancellationToken ct)
{
    if (lastEvent == "2") yield break;
    if (lastEvent != "1")
        yield return new SseItem<ProgressUpdate>(new("running", 1), "progress") { EventId = "1" };
    await Task.Delay(100, ct);
    yield return new SseItem<ProgressUpdate>(new("done", 2), "progress") { EventId = "2" };
}

#if NET11_0_OR_GREATER
public union CourseState(Available, Missing);
public sealed record Available(string Code);
public sealed record Missing(string Reason);
#endif
public sealed record Receipt(string Student, string Course);
public sealed record Failure(string Code);
public sealed record ProgressUpdate(string State, int Sequence);
public sealed record Enrollment([Required] string Student, [Required] string Course)
#if NET11_0_OR_GREATER
    : IAsyncValidatableObject
#endif
{
#if NET11_0_OR_GREATER
    public IEnumerable<ValidationResult> Validate(ValidationContext context) =>
        throw new InvalidOperationException("Use ValidateAsync.");

    public async IAsyncEnumerable<ValidationResult> ValidateAsync(
        ValidationContext context, [EnumeratorCancellation] CancellationToken ct)
    {
        var data = (NpgsqlDataSource)context.GetService(typeof(NpgsqlDataSource))!;
        if (await Exists(data, Student, Course, ct))
            yield return new ValidationResult("already enrolled", [nameof(Course)]);
    }
#endif
    public static async Task<bool> Exists(
        NpgsqlDataSource data, string student, string course, CancellationToken ct)
    {
        await using var command = data.CreateCommand(
            "SELECT 1 FROM enrollments WHERE student = $1 AND course = $2");
        command.Parameters.AddWithValue(student);
        command.Parameters.AddWithValue(course);
        return await command.ExecuteScalarAsync(ct) is not null;
    }
}
