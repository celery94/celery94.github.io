import json
from pathlib import Path

paths = Path("snapshots")
doc = json.loads((paths / "net11-compat.json").read_text(encoding="utf-8"))
stream = doc["paths"]["/progress"]["get"]["responses"]["200"]["content"]["text/event-stream"]
del stream["x-oai-itemSchema"]
stream["schema"] = {"type": "string"}
(paths / "net11-angular.json").write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
