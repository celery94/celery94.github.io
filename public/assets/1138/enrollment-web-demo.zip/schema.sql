CREATE TABLE courses(code text PRIMARY KEY);
CREATE TABLE enrollments (
    student text NOT NULL,
    course text NOT NULL REFERENCES courses(code),
    PRIMARY KEY (student, course)
);
INSERT INTO courses(code) VALUES ('C101'), ('C102');
