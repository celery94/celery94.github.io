# 选课服务双版本 Demo

需要 .NET SDK 10.0.402 和 11.0.100、PostgreSQL 18、Python 3，以及复制 Angular 生成结果时所需的 Java 和 OpenAPI Generator CLI 7.22.0。数据全部为合成样本，应用只用于本机测试。

1. 使用本地测试实例，在 127.0.0.1:55431 创建角色 `series` 和两个空数据库 `net10_baseline`、`net11_upgrade`。在两个库各执行一次 `schema.sql`。使用带密码的实例时将密码放入本机进程环境变量 PGPASSWORD，并通过 SERIES_PG_TEMPLATE 指定 Npgsql 连接模板，保留 `{db}` 占位符。测试脚本会清空两个 Demo 数据库中的 enrollments。
2. Windows 下可用 SERIES_PG_BIN 指定 PostgreSQL 安装的 bin 目录。分别进入 net10-baseline 和 net11-upgrade 执行 `dotnet build`，以便各自的 global.json 生效。
3. 在解压目录内运行 `python verify.py`。脚本会启动对应应用、运行请求、收集文档和响应到 snapshots，并终止进程。
4. 运行 `python prepare-angular.py`。使用以下命令从基线和兼容文档重新生成客户端。

```powershell
java -jar openapi-generator-cli-7.22.0.jar generate -g typescript-angular -i snapshots/net10-baseline.json -o clients/net10-baseline --additional-properties=ngVersion=20.3.0
java -jar openapi-generator-cli-7.22.0.jar generate -g typescript-angular -i snapshots/net11-angular.json -o clients/net11-angular --additional-properties=ngVersion=20.3.0
git diff --no-index -- clients/net10-baseline clients/net11-angular
```

`/demo-session` 只识别文档中的模拟会话标记。`/progress` 是可重复播放的两事件夹具。在部署环境用实际身份提供方和代理重新跑浏览器回归。
