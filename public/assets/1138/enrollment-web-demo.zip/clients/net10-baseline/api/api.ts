export * from './program.service';
import { ProgramService } from './program.service';
export * from './web.service';
import { WebService } from './web.service';
export const APIS = [ProgramService, WebService];
