using Microsoft.AspNetCore.SignalR.Client;

string token = "demo-v1";
await using var hub = new HubConnectionBuilder()
    .WithUrl("http://127.0.0.1:5115/import", options =>
        options.AccessTokenProvider = () => Task.FromResult<string?>(token))
    .Build();
var first = new TaskCompletionSource<int>(TaskCreationOptions.RunContinuationsAsynchronously);
var cancelled = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
using var onProgress = hub.On<int>("Progress", value => first.TrySetResult(value));
using var onCancelled = hub.On("Cancelled", () => cancelled.TrySetResult());
await hub.StartAsync();
string? connection = hub.ConnectionId;
Console.WriteLine(await hub.InvokeAsync<string>("Revision"));
token = "demo-v2";
await hub.RefreshAuthenticationAsync();
string revision = await hub.InvokeAsync<string>("Revision");
if (revision != "demo-v2" || connection is null || hub.ConnectionId != connection)
    throw new InvalidOperationException("Refresh did not update the existing connection.");
Console.WriteLine(revision + " (same connection)");

using var cts = new CancellationTokenSource();
Task work = hub.InvokeAsync("Import", cts.Token);
Console.WriteLine("Progress: " + await first.Task.WaitAsync(TimeSpan.FromSeconds(5)));
cts.Cancel();
try { await work; }
catch (OperationCanceledException) when (cts.IsCancellationRequested) { }
await cancelled.Task.WaitAsync(TimeSpan.FromSeconds(5));
Console.WriteLine("Server observed cancellation.");
