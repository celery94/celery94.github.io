from pathlib import Path
import subprocess
import time
from urllib.error import HTTPError, URLError
from urllib.request import urlopen

root = Path(__file__).resolve().parent
for project in ("Server", "Client"):
    subprocess.run(["dotnet", "build", str(root / project)], check=True)
with (root / "server.log").open("w", encoding="utf-8") as log:
    server = subprocess.Popen(["dotnet", str(root / "Server/bin/Debug/net11.0/Server.dll"),
                               "--urls", "http://127.0.0.1:5115"], stdout=log, stderr=log)
    try:
        for attempt in range(30):
            try:
                urlopen("http://127.0.0.1:5115/", timeout=1)
            except HTTPError as e:
                if e.code == 404:
                    break
            except URLError:
                time.sleep(.25)
        else:
            raise RuntimeError("Loopback server was not ready")
        result = subprocess.check_output(["dotnet", str(root / "Client/bin/Debug/net11.0/Client.dll")],
                                         text=True, timeout=20)
        (root / "client.txt").write_text(result, encoding="utf-8")
        print(result)
    finally:
        server.terminate()
        server.wait(timeout=10)
