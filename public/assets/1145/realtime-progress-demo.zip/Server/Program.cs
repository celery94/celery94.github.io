using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSignalR();
builder.Services.AddAuthorization();
builder.Services.AddAuthentication("Demo")
    .AddScheme<AuthenticationSchemeOptions, DemoAuthentication>("Demo", _ => { });
var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();
app.MapHub<ImportHub>("/import", options =>
{
    options.EnableAuthenticationRefresh = true;
    options.CloseOnAuthenticationExpiration = true;
    options.OnAuthenticationRefresh = context => Task.FromResult(
        context.PreviousUser.FindFirstValue(ClaimTypes.NameIdentifier) ==
        context.NewUser.FindFirstValue(ClaimTypes.NameIdentifier));
}).RequireAuthorization();
app.Run();

public sealed class ImportHub : Hub
{
    public string? Revision() => Context.User?.FindFirstValue("revision");

    public async Task Import(CancellationToken ct)
    {
        await Clients.Caller.SendAsync("Progress", 1, ct);
        try
        {
            await Task.Delay(TimeSpan.FromSeconds(20), ct);
            await Clients.Caller.SendAsync("Progress", 100, ct);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            await Clients.Caller.SendAsync("Cancelled");
        }
    }
}

// Loopback-only test fixture. Real deployments must use their own validated auth provider.
public sealed class DemoAuthentication(
    IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder)
    : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        string? bearer = Request.Headers.Authorization.FirstOrDefault();
        string? token = bearer?.StartsWith("Bearer ", StringComparison.Ordinal) == true
            ? bearer[7..] : Request.Query["access_token"].FirstOrDefault();
        if (token is not ("demo-v1" or "demo-v2"))
            return Task.FromResult(AuthenticateResult.NoResult());

        var user = new ClaimsPrincipal(new ClaimsIdentity(
            [new Claim(ClaimTypes.NameIdentifier, "student-1"), new Claim("revision", token)], Scheme.Name));
        var properties = new AuthenticationProperties { ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(10) };
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(user, properties, Scheme.Name)));
    }
}
