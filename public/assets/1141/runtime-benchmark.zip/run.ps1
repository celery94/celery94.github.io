$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$cases = @(
  @{ Name = "net10"; Framework = "net10.0"; Async = "false" },
  @{ Name = "net11"; Framework = "net11.0"; Async = "false" },
  @{ Name = "net11-async"; Framework = "net11.0"; Async = "true" }
)
foreach ($case in $cases) {
  dotnet build --no-incremental -f $case.Framework -c Release -o "out/$($case.Name)" "-p:EnableRuntimeAsync=$($case.Async)"
  if ($LASTEXITCODE -ne 0) { throw "Build failed for $($case.Name)" }
}
dotnet publish -c Release -f net11.0 -r win-x64 -p:PublishAot=true -o out/aot
if ($LASTEXITCODE -ne 0) { throw "Native publish failed" }
foreach ($case in $cases) {
  dotnet "out/$($case.Name)/Perf.dll" | Set-Content -Encoding utf8 "$($case.Name).csv"
  if ($LASTEXITCODE -ne 0) { throw "Run failed for $($case.Name)" }
}
& "out/aot/Perf.exe" | Set-Content -Encoding utf8 aot.csv
if ($LASTEXITCODE -ne 0) { throw "Native run failed" }
Get-Item out/aot/Perf.exe | Select-Object Name,Length
