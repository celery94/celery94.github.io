using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

const int iterations = 1_000_000;
int[] values = Enumerable.Range(1, 128).ToArray();
Console.WriteLine($"{RuntimeInformation.FrameworkDescription}, {RuntimeInformation.ProcessArchitecture}, dynamicCode={RuntimeFeature.IsDynamicCodeSupported}");
await Measure("indexed", () => new ValueTask<int>(Sum(values)));
await Measure("async-completed", Completed);

static async Task Measure(string name, Func<ValueTask<int>> work)
{
    long checksum = 0;
    for (int i = 0; i < 100_000; i++) checksum += await work();
    for (int round = 0; round < 7; round++)
    {
        long before = GC.GetTotalAllocatedBytes(precise: true);
        long start = Stopwatch.GetTimestamp();
        for (int i = 0; i < iterations; i++) checksum += await work();
        double seconds = Stopwatch.GetElapsedTime(start).TotalSeconds;
        long bytes = GC.GetTotalAllocatedBytes(precise: true) - before;
        Console.WriteLine(FormattableString.Invariant(
            $"{name},{round + 1},{iterations / seconds:F0},{bytes / (double)iterations:F3}"));
    }
    Console.WriteLine($"checksum={checksum}");
}
[MethodImpl(MethodImplOptions.NoInlining)]
static int Sum(int[] values)
{
    int total = 0;
    for (int i = 0; i < values.Length; i++) total += values[i];
    return total;
}
[MethodImpl(MethodImplOptions.NoInlining)]
static async ValueTask<int> Completed() => 1 + await GetCompleted();
[MethodImpl(MethodImplOptions.NoInlining)]
static Task<int> GetCompleted() => Task.FromResult(42);
