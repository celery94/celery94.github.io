using Microsoft.EntityFrameworkCore;
using Microsoft.Data.Sqlite;

using var connection = new SqliteConnection("Data Source=:memory:");
connection.Open();
using var db = new LedgerDb(connection);
db.Database.EnsureCreated();
db.Expected.AddRange(new Entry(1, "C101", 2), new Entry(2, "C102", 1));
db.Paid.AddRange(new Entry(1, "C101", 1), new Entry(2, "C101", 2), new Entry(3, "C103", 1));
db.Courses.AddRange(new Course { Code = "C101", Students = [new Student { Name = "S01" }, new Student { Name = "S02" }] },
    new Course { Code = "C102" });
db.SaveChanges();
Console.WriteLine($"SQLite {connection.ServerVersion}, EF {typeof(DbContext).Assembly.GetName().Version}");
var expected = db.Expected.GroupBy(x => x.Code)
    .Select(g => new { Code = g.Key, Amount = g.Sum(x => x.Amount) });
var paid = db.Paid.GroupBy(x => x.Code)
    .Select(g => new { Code = g.Key, Amount = g.Sum(x => x.Amount) });

#if NET11_0_OR_GREATER
var report = expected.FullJoin(paid, e => e.Code, p => p.Code,
    (e, p) => new { Code = e!.Code ?? p!.Code, Expected = (int?)e!.Amount ?? 0, Paid = (int?)p!.Amount ?? 0 })
    .OrderBy(x => x.Code);
#else
var left = from e in expected
           join p in paid on e.Code equals p.Code into matches
           from p in matches.DefaultIfEmpty()
           select new { e.Code, Expected = e.Amount, Paid = (int?)p!.Amount ?? 0 };
var rightOnly = from p in paid
                where !expected.Any(e => e.Code == p.Code)
                select new { p.Code, Expected = 0, Paid = p.Amount };
var report = left.Concat(rightOnly).OrderBy(x => x.Code);
#endif
Print("Report", report, connection);
foreach (var row in report) Console.WriteLine(row);
Print("GroupBy", paid, connection);
var split = db.Courses.Include(x => x.Students).OrderBy(x => x.Code).AsSplitQuery();
Print("Split SQL (first statement)", split, connection);
foreach (var course in split) Console.WriteLine($"{course.Code}: {course.Students.Count}");
static void Print<T>(string name, IQueryable<T> query, SqliteConnection connection)
{
    var sql = query.ToQueryString();
    Console.WriteLine($"{name}\n{sql}");
    using var plan = connection.CreateCommand();
    plan.CommandText = "EXPLAIN QUERY PLAN " + sql.Split("This LINQ", 2)[0].TrimEnd();
    using var reader = plan.ExecuteReader();
    while (reader.Read()) Console.WriteLine(reader.GetString(3));
}

public record Entry(int Id, string Code, int Amount);
public class Course
{
    public string Code { get; init; } = "";
    public List<Student> Students { get; init; } = [];
}
public class Student
{
    public int Id { get; set; }
    public string Name { get; init; } = "";
    public string CourseCode { get; set; } = "";
}
public class LedgerDb(SqliteConnection connection) : DbContext
{
    public DbSet<Entry> Expected => Set<Entry>("Expected");
    public DbSet<Entry> Paid => Set<Entry>("Paid");
    public DbSet<Course> Courses => Set<Course>();
    protected override void OnConfiguring(DbContextOptionsBuilder options) =>
        options.UseSqlite(connection).LogTo(Console.WriteLine,
            [Microsoft.EntityFrameworkCore.Diagnostics.RelationalEventId.CommandExecuted]);
    protected override void OnModelCreating(ModelBuilder model)
    {
        model.SharedTypeEntity<Entry>("Expected");
        model.SharedTypeEntity<Entry>("Paid");
        model.Entity<Course>().HasKey(x => x.Code);
    }
}
